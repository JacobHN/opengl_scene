/**
 * creates a 3d virtual world using objects created in blender and objects created explicitly with vertexs that
 * can be traversed through using the wasdeq and up down left right arrow keys.
 *
 * @author Jacob Hua
 * @version 1.0
 * @since 2021-03-19
 *
 */
package a3;

import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.GL4;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLContext;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.Animator;
import org.joml.*;

import javax.swing.*;
import javax.swing.event.MouseInputListener;
import java.awt.event.*;
import java.lang.Math;
import java.nio.FloatBuffer;

import static com.jogamp.opengl.GL.*;
import static com.jogamp.opengl.GL2ES2.*;
import static com.jogamp.opengl.GL2ES2.GL_TEXTURE_COMPARE_FUNC;

public class Starter extends JFrame implements GLEventListener, KeyListener, MouseListener, MouseWheelListener, MouseInputListener {

    private GLCanvas myCanvas;

    private int renderingProgram;
    private int axesRenderingProgram;
    private int shadowRenderingProgram;

    private int vao[] = new int[1];
    private int vbo[] = new int[50];
    private float cameraX, cameraY, cameraZ;

    //world matrices
    private FloatBuffer vals = Buffers.newDirectFloatBuffer(16);
    private Matrix4fStack mvStack = new Matrix4fStack(8);
    private Matrix4f pMat = new Matrix4f();
    private Matrix4f vMat = new Matrix4f();
    private Matrix4f mMat = new Matrix4f();

    private Matrix4f invTrMat = new Matrix4f();



    private int mvLoc;
    private int projLoc;
    private int nLoc;
    private int sLoc;
    private float aspect;

    //texture
    private int dummyTexture;
    private int gordonFaceTexture;
    private int importedModelTexture;
    private int shuttleTexture;
    private int mushroomTexture;
    private int cubeHeadTexture;
    private int floorTexture;
    private int whiteTexture;
    private int treeTexture;

    //model
    private ImportedModel mushroom;
    private ImportedModel shuttle;
    private CubeHead cubeHead;
    private Cube cube;
    private Rectangle rectangle;
    private FloorModel floor;
    private ImportedModel grid;
    private ImportedModel tree;

    //time variables
    private long elapsedTime;
    private long startTime;
    private long currentTime;
    private float tf;

    //camera variables
    Camera camera;

    //light variables
    private float amt = 0.0f;
    private int globalAmbLoc, ambLoc, diffLoc,
            specLoc, posLoc, mambLoc, mdiffLoc, mspecLoc, mshiLoc;
    private Vector3f currentLightPos = new Vector3f();
    private float[] lightPos = new float[3];

    float[] globalAmbient = { 0.6f, 0.6f, 0.6f, 1.0f };
    float[] lightAmbient = { 0.1f, 0.1f, 0.1f, 1.0f };
    float[] lightDiffuse = { 1.0f, 1.0f, 1.0f, 1.0f };
    float[] lightSpecular = { 1.0f, 1.0f, 1.0f, 1.0f };

    private Vector3f initialLightLoc = new Vector3f(5.0f, 3.0f, 2.0f);


    //material variables
    float[] matAmb = Utils.silverAmbient();
    float[] matDif = Utils.silverDiffuse();
    float[] matSpe = Utils.silverSpecular();
    float matShi = Utils.silverShininess();

    //shadow variables
    private int scSizeX, scSizeY;
    private int [] shadowTex = new int[1];
    private int [] shadowBuffer = new int[1];
    private Matrix4f lightVmat = new Matrix4f();
    private Matrix4f lightPmat = new Matrix4f();
    private Matrix4f shadowMVP1 = new Matrix4f();
    private Matrix4f shadowMVP2 = new Matrix4f();
    private Matrix4f b = new Matrix4f();

    Vector3f origin = new Vector3f(0,0,0);
    Vector3f up = new Vector3f(0,1,0);

    private Matrix4fStack shadowMVPStack1 = new Matrix4fStack(8);
    private Matrix4fStack shadowMVPStack2 = new Matrix4fStack(8);


    //boolean variables
    boolean axisFlag = true;
    int globalAmbSwitch = 0;


    //light movement variables
    int originalDraggedPositionX;
    int originalDraggedPositionY;
    Vector3f lightIncramentX = new Vector3f(0.1f,0.0f,0.0f);
    Vector3f lightIncramentY = new Vector3f(0.0f,0.1f,0.0f);
    Vector3f lightIncramentZ = new Vector3f(0.0f,0.0f,0.1f);


    //object locations
    Vector3f tree1Loc = new Vector3f(.8f, 0.0f, 0.0f);
    Vector3f tree2Loc = new Vector3f(2.5f, 0.0f,0.8f);
    Vector3f tree3Loc = new Vector3f(-1.5f, 0.0f, -0.8f);
    Vector3f mushroom1Loc = new Vector3f(0.0f, 0.0f, 0.0f);
    Vector3f mushroom1Scale = new Vector3f(0.05f, 0.05f, 0.05f);
    Vector3f mushroom2Loc = new Vector3f(0.2f, 0.0f, 0.3f);
    Vector3f mushroom2Scale = new Vector3f(0.05f, 0.05f, 0.05f);
    Vector3f floorLoc = new Vector3f(0.0f, 0.0f, 0.0f);



    /**
     * constructor
     */
    public Starter() {
        setTitle("assignment 3");
        setSize(600,600);
        myCanvas = new GLCanvas();
        myCanvas.addGLEventListener(this);
        myCanvas.addKeyListener(this);
        myCanvas.addMouseListener(this);
        myCanvas.addMouseWheelListener(this);
        myCanvas.addMouseMotionListener(this);
        this.add(myCanvas);
        this.setVisible(true);
        Animator animator = new Animator(myCanvas);
        animator.start();
    }

    /**
     * initializes program
     * @param glAutoDrawable
     */
    @Override
    public void init(GLAutoDrawable glAutoDrawable) {
        GL4 gl = (GL4) GLContext.getCurrentGL();
        //pass 2 render
        renderingProgram = Utils.createShaderProgram("a3/vertShaderLight.glsl", "a3/fragShaderLight.glsl");
        //axes render
        axesRenderingProgram = Utils.createShaderProgram("a3/axesVertShader.glsl", "a3/axesFragShader.glsl");
        //pass 1 render
        shadowRenderingProgram = Utils.createShaderProgram("a3/vertShaderPassOne.glsl", "a3/fragShaderPassOne.glsl");
        startTime = System.currentTimeMillis();

        cameraX = 0.0f; cameraY = 0.0f; cameraZ = 2.0f;
        setupVertices();
        setupShadowBuffers();
        //camera position and angle variables
        camera = new Camera(0, 2, 5);

        //load textures
        dummyTexture = Utils.loadTexture("a3/brick1.jpg");
        gordonFaceTexture = Utils.loadTexture("a3/gordonPic.jpg");
        shuttleTexture = Utils.loadTexture("a3/spstob_1.jpg");
        mushroomTexture = Utils.loadTexture("a3/mushroom_color.png");
        cubeHeadTexture = Utils.loadTexture("a3/cubehead.png");
        floorTexture = Utils.loadTexture("a3/grass.jpg");
        whiteTexture = Utils.loadTexture("a3/white.png");
        treeTexture = Utils.loadTexture("a3/tree_texture2.png");

        b.set(
                0.5f, 0.0f, 0.0f, 0.0f,
                0.0f, 0.5f, 0.0f, 0.0f,
                0.0f, 0.0f, 0.5f, 0.0f,
                0.5f, 0.5f, 0.5f, 1.0f);

        //print out system aOpenGL, JOGL and JAVA
        System.out.println("OpenGL version: " +  gl.glGetString(GL_VERSION));
        System.out.println("JOGL version: " + Package.getPackage("com.jogamp.opengl").getImplementationVersion());
        System.out.println("Java version: " + System.getProperty("java.version"));
    }



    @Override
    public void dispose(GLAutoDrawable glAutoDrawable) {}

    /**
     * displays objects onto screen at clock speed
     * @param glAutoDrawable
     */
    @Override
    public void display(GLAutoDrawable glAutoDrawable) {
        GL4 gl = (GL4) GLContext.getCurrentGL();
        gl.glClear(GL_DEPTH_BUFFER_BIT);
        gl.glClear(GL_COLOR_BUFFER_BIT);


        currentLightPos.set(initialLightLoc);
        //amt += 0.5f;
        //currentLightPos.rotateAxis((float)Math.toRadians(amt), 0.0f, 1.0f, 0.0f);
        lightVmat.identity().setLookAt(currentLightPos, origin, up);
        lightPmat.identity().setPerspective((float) Math.toRadians(60.0f), aspect, 0.1f, 1000.0f);

        gl.glBindFramebuffer(GL_FRAMEBUFFER, shadowBuffer[0]);
        gl.glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, shadowTex[0], 0);

        gl.glDrawBuffer(GL_NONE);
        gl.glEnable(GL_DEPTH_TEST);
        gl.glEnable(GL_POLYGON_OFFSET_FILL);
        gl.glPolygonOffset(3.0f, 5.0f);

        passOne();

        gl.glDisable(GL_POLYGON_OFFSET_FILL);

        gl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
        gl.glActiveTexture(GL_TEXTURE1);
        gl.glBindTexture(GL_TEXTURE_2D, shadowTex[0]);

        gl.glDrawBuffer(GL_FRONT);

        passTwo();

    }

    private void passOne(){
        GL4 gl = (GL4) GLContext.getCurrentGL();

        gl.glUseProgram(shadowRenderingProgram);
        shadowMVPStack1.identity();
        mMat.identity();
        //mMat.translate(0.0f,0.0f,0.0f);

        shadowMVPStack1.pushMatrix();
        shadowMVPStack1.mul(lightPmat);
        shadowMVPStack1.mul(lightVmat);
        shadowMVPStack1.mul(mMat);

        //mushroom shadow
        shadowMVPStack1.pushMatrix();
        shadowMVPStack1.translate(mushroom1Loc);
        shadowMVPStack1.pushMatrix();//mushroom scale
        shadowMVPStack1.scale(mushroom1Scale);
        sLoc = gl.glGetUniformLocation(shadowRenderingProgram, "shadowMVP");
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack1.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
        gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glClear(GL_DEPTH_BUFFER_BIT);
        gl.glEnable(GL_CULL_FACE);
        gl.glFrontFace(GL_CCW);
        gl.glEnable(GL_DEPTH_TEST);
        gl.glDepthFunc(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, mushroom.getNumVertices());

        shadowMVPStack1.popMatrix();
        shadowMVPStack1.popMatrix();

        //mushroom 2 shadow
        shadowMVPStack1.pushMatrix();
        shadowMVPStack1.translate(mushroom2Loc);
        shadowMVPStack1.pushMatrix();//mushroom scale
        shadowMVPStack1.scale(mushroom1Scale);
        sLoc = gl.glGetUniformLocation(shadowRenderingProgram, "shadowMVP");
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack1.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
        gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glEnable(GL_CULL_FACE);
        gl.glFrontFace(GL_CCW);
        gl.glEnable(GL_DEPTH_TEST);
        gl.glDepthFunc(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, mushroom.getNumVertices());

        shadowMVPStack1.popMatrix();
        shadowMVPStack1.popMatrix();

        //tree shadow
        shadowMVPStack1.pushMatrix();
        shadowMVPStack1.translate(tree1Loc);
        shadowMVPStack1.pushMatrix();//mushroom scale
        shadowMVPStack1.scale(0.5f, 0.5f, 0.5f);
        sLoc = gl.glGetUniformLocation(shadowRenderingProgram, "shadowMVP");
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack1.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
        gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        //gl.glClear(GL_DEPTH_BUFFER_BIT);
        gl.glEnable(GL_CULL_FACE);
        gl.glFrontFace(GL_CCW);
        gl.glEnable(GL_DEPTH_TEST);
        gl.glDepthFunc(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, tree.getNumVertices());

        shadowMVPStack1.popMatrix();
        shadowMVPStack1.popMatrix();

        //tree shadow
        shadowMVPStack1.pushMatrix();
        shadowMVPStack1.translate(tree2Loc);
        shadowMVPStack1.pushMatrix();//mushroom scale
        shadowMVPStack1.scale(0.5f, 0.5f, 0.5f);
        sLoc = gl.glGetUniformLocation(shadowRenderingProgram, "shadowMVP");
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack1.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
        gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        //gl.glClear(GL_DEPTH_BUFFER_BIT);
        gl.glEnable(GL_CULL_FACE);
        gl.glFrontFace(GL_CCW);
        gl.glEnable(GL_DEPTH_TEST);
        gl.glDepthFunc(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, tree.getNumVertices());

        shadowMVPStack1.popMatrix();
        shadowMVPStack1.popMatrix();

        //tree shadow
        shadowMVPStack1.pushMatrix();
        shadowMVPStack1.translate(tree3Loc);
        shadowMVPStack1.pushMatrix();//mushroom scale
        shadowMVPStack1.scale(0.5f, 0.5f, 0.5f);
        sLoc = gl.glGetUniformLocation(shadowRenderingProgram, "shadowMVP");
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack1.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
        gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        //gl.glClear(GL_DEPTH_BUFFER_BIT);
        gl.glEnable(GL_CULL_FACE);
        gl.glFrontFace(GL_CCW);
        gl.glEnable(GL_DEPTH_TEST);
        gl.glDepthFunc(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, tree.getNumVertices());

        shadowMVPStack1.popMatrix();
        shadowMVPStack1.popMatrix();

        //floor shadow
        shadowMVPStack1.pushMatrix();//floor translation
        shadowMVPStack1.translate(floorLoc);
        shadowMVPStack1.pushMatrix();//floor scale
        shadowMVPStack1.scale(10.0f, 10.0f, 10.0f);

        sLoc = gl.glGetUniformLocation(shadowRenderingProgram, "shadowMVP");
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack1.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
        gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glEnable(GL_CULL_FACE);
        gl.glFrontFace(GL_CCW);
        gl.glEnable(GL_DEPTH_TEST);
        gl.glDepthFunc(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, grid.getNumVertices());

        shadowMVPStack1.popMatrix();
        shadowMVPStack1.popMatrix();

        shadowMVPStack1.popMatrix();



    }

    private void passTwo(){
        GL4 gl = (GL4) GLContext.getCurrentGL();


        elapsedTime = System.currentTimeMillis() - startTime;
        tf = (float)elapsedTime/1000;

        gl.glUseProgram(renderingProgram);

        //global ambient switch
        int globalAmbBool = gl.glGetUniformLocation(renderingProgram, "onlyGlobalAmbient");
        gl.glProgramUniform1i(renderingProgram, globalAmbBool, globalAmbSwitch);

        mvLoc = gl.glGetUniformLocation(renderingProgram, "mv_matrix");
        projLoc = gl.glGetUniformLocation(renderingProgram, "proj_matrix");
        nLoc = gl.glGetUniformLocation(renderingProgram, "norm_matrix");
        sLoc = gl.glGetUniformLocation(renderingProgram, "shadowMVP");

        //vMat.translation(-cameraX, -cameraY, -cameraZ);

        aspect = (float) myCanvas.getWidth() / (float) myCanvas.getHeight();
        pMat.identity().setPerspective((float) Math.toRadians(60.0f), aspect, 0.1f, 1000.0f);
        gl.glUniformMatrix4fv(projLoc, 1, false, pMat.get(vals));

        //rotation matrix
        camera.updateCameraRotation();
        //position matrix
        camera.updateCameraPosition();

        vMat = camera.vMatrix();
        mMat.identity();
        //mMat.translate(0.0f,0.0f,0.0f);



        mvStack.pushMatrix();//pushes camera onto matrix
        mvStack.identity();
        mvStack.mul(vMat);
        mvStack.mul(mMat);

        mvStack.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));
        gl.glUniformMatrix4fv(projLoc, 1, false, pMat.get(vals));
        gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));

        //light cube
        mvStack.pushMatrix();//light cube translation
        mvStack.translate(currentLightPos);
        mvStack.pushMatrix();//light cube scale
        mvStack.scale(0.1f, 0.1f, 0.1f);
        gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER,vbo[20]);
        gl.glVertexAttribPointer(0,3,GL_FLOAT,false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[21]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, whiteTexture);

        gl.glEnable(GL_CULL_FACE);
        gl.glEnable(GL_CCW);
        gl.glEnable(GL_DEPTH_TEST);
        gl.glEnable(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, 36);

        mvStack.popMatrix();
        mvStack.popMatrix();


        //install lighting into stack
        installLight(renderingProgram, mvStack);

        //shadow creation
        shadowMVPStack2.identity();
        shadowMVPStack2.mul(b);
        shadowMVPStack2.mul(lightPmat);
        shadowMVPStack2.mul(lightVmat);
        shadowMVPStack2.mul(mMat);

        changeToSilverMaterial();
        //creates mushroom
        mvStack.pushMatrix();//mushroom translation
        mvStack.translate(mushroom1Loc);
        mvStack.pushMatrix();//mushroom scale
        mvStack.scale(mushroom1Scale);

        shadowMVPStack2.pushMatrix();//mushroom translation
        shadowMVPStack2.translate(mushroom1Loc);
        shadowMVPStack2.pushMatrix();//mushroom scale
        shadowMVPStack2.scale(mushroom1Scale);

        mvStack.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));
        gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack2.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER,vbo[4]);
        gl.glVertexAttribPointer(0,3,GL_FLOAT,false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
        gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, mushroomTexture);


        gl.glEnable(GL_DEPTH_TEST);
        gl.glEnable(GL_LEQUAL);
        gl.glEnable(GL_CULL_FACE);

        gl.glDrawArrays(GL_TRIANGLES, 0, mushroom.getNumVertices());

        mvStack.popMatrix(); //mushroom scale
        mvStack.popMatrix(); //mushroom translation

        shadowMVPStack2.popMatrix();
        shadowMVPStack2.popMatrix();

        //creates mushroom 2
        mvStack.pushMatrix();//mushroom translation
        mvStack.translate(mushroom2Loc);
        mvStack.pushMatrix();//mushroom scale
        mvStack.scale(mushroom2Scale);

        shadowMVPStack2.pushMatrix();//mushroom translation
        shadowMVPStack2.translate(mushroom2Loc);
        shadowMVPStack2.pushMatrix();//mushroom scale
        shadowMVPStack2.scale(mushroom2Scale);

        mvStack.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));
        gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack2.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER,vbo[4]);
        gl.glVertexAttribPointer(0,3,GL_FLOAT,false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
        gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, mushroomTexture);


        gl.glEnable(GL_DEPTH_TEST);
        gl.glEnable(GL_LEQUAL);
        gl.glEnable(GL_CULL_FACE);

        gl.glDrawArrays(GL_TRIANGLES, 0, mushroom.getNumVertices());

        mvStack.popMatrix(); //mushroom scale
        mvStack.popMatrix(); //mushroom translation

        shadowMVPStack2.popMatrix();
        shadowMVPStack2.popMatrix();

        //tree model
        mvStack.pushMatrix();//tree translation
        mvStack.translate(tree1Loc);
        mvStack.pushMatrix();//mushroom scale
        mvStack.scale(0.5f, 0.5f, 0.5f);

        shadowMVPStack2.pushMatrix();//tree translation
        shadowMVPStack2.translate(tree1Loc);
        shadowMVPStack2.pushMatrix();//tree scale
        shadowMVPStack2.scale(0.5f, 0.5f, 0.5f);

        mvStack.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));
        gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack2.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER,vbo[11]);
        gl.glVertexAttribPointer(0,3,GL_FLOAT,false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
        gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, treeTexture);


        gl.glEnable(GL_DEPTH_TEST);
        gl.glEnable(GL_LEQUAL);
        gl.glEnable(GL_CULL_FACE);

        gl.glDrawArrays(GL_TRIANGLES, 0, tree.getNumVertices());

        mvStack.popMatrix(); //tree scale
        mvStack.popMatrix(); //tree translation

        shadowMVPStack2.popMatrix();
        shadowMVPStack2.popMatrix();

        //tree model 2
        mvStack.pushMatrix();//tree translation
        mvStack.translate(tree2Loc);
        mvStack.pushMatrix();//mushroom scale
        mvStack.scale(0.5f, 0.5f, 0.5f);

        shadowMVPStack2.pushMatrix();//tree translation
        shadowMVPStack2.translate(tree2Loc);
        shadowMVPStack2.pushMatrix();//tree scale
        shadowMVPStack2.scale(0.5f, 0.5f, 0.5f);

        mvStack.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));
        gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack2.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER,vbo[11]);
        gl.glVertexAttribPointer(0,3,GL_FLOAT,false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
        gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, treeTexture);


        gl.glEnable(GL_DEPTH_TEST);
        gl.glEnable(GL_LEQUAL);
        gl.glEnable(GL_CULL_FACE);

        gl.glDrawArrays(GL_TRIANGLES, 0, tree.getNumVertices());

        mvStack.popMatrix(); //tree scale
        mvStack.popMatrix(); //tree translation

        shadowMVPStack2.popMatrix();
        shadowMVPStack2.popMatrix();


        //tree model 3
        mvStack.pushMatrix();//tree translation
        mvStack.translate(tree3Loc);
        mvStack.pushMatrix();//tree scale
        mvStack.scale(0.5f, 0.5f, 0.5f);

        shadowMVPStack2.pushMatrix();//tree translation
        shadowMVPStack2.translate(tree3Loc);
        shadowMVPStack2.pushMatrix();//tree scale
        shadowMVPStack2.scale(0.5f, 0.5f, 0.5f);

        mvStack.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));
        gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack2.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER,vbo[11]);
        gl.glVertexAttribPointer(0,3,GL_FLOAT,false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
        gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, treeTexture);


        gl.glEnable(GL_DEPTH_TEST);
        gl.glEnable(GL_LEQUAL);
        gl.glEnable(GL_CULL_FACE);

        gl.glDrawArrays(GL_TRIANGLES, 0, tree.getNumVertices());

        mvStack.popMatrix(); //tree scale
        mvStack.popMatrix(); //tree translation

        shadowMVPStack2.popMatrix();
        shadowMVPStack2.popMatrix();

        changeToMatMaterial();
        //floor
        mvStack.pushMatrix();//floor translation
        mvStack.translate(floorLoc);
        mvStack.pushMatrix();//floor scale
        mvStack.scale(10.0f, 10.0f, 10.0f);

        shadowMVPStack2.pushMatrix();//floor translation
        shadowMVPStack2.translate(floorLoc);
        shadowMVPStack2.pushMatrix();//floor scale
        shadowMVPStack2.scale(10.0f, 10.0f, 10.0f);

        mvStack.invert(invTrMat);
        invTrMat.transpose(invTrMat);

        gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));
        gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
        gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVPStack2.get(vals));

        gl.glBindBuffer(GL_ARRAY_BUFFER,vbo[8]);
        gl.glVertexAttribPointer(0,3,GL_FLOAT,false, 0, 0);
        gl.glEnableVertexAttribArray(0);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
        gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(1);

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(GL_TEXTURE_2D, floorTexture);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
        gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
        gl.glEnableVertexAttribArray(2);

        gl.glEnable(GL_DEPTH_TEST);
        gl.glEnable(GL_LEQUAL);

        gl.glDrawArrays(GL_TRIANGLES, 0, grid.getNumVertices());
        mvStack.popMatrix(); // scale
        mvStack.popMatrix(); // translate

        shadowMVPStack2.popMatrix();
        shadowMVPStack2.popMatrix();


        //creates axis if spacebar is pushed
        if(axisFlag) {
            mvStack.pushMatrix();
            gl.glUseProgram(axesRenderingProgram);
            mvLoc = gl.glGetUniformLocation(axesRenderingProgram, "mv_matrix");
            projLoc = gl.glGetUniformLocation(axesRenderingProgram, "proj_matrix");

            gl.glUniformMatrix4fv(projLoc, 1, false, pMat.get(vals));
            gl.glUniformMatrix4fv(mvLoc, 1, false, mvStack.get(vals));


            gl.glDrawArrays(GL_LINES, 0, 6);
            mvStack.popMatrix();
        }

        mvStack.popMatrix();//pop camera
        currentTime = System.currentTimeMillis() - startTime;


    }

    @Override
    public void reshape(GLAutoDrawable glAutoDrawable, int i, int i1, int i2, int i3) {
        GL4 gl = (GL4) GLContext.getCurrentGL();

        aspect = (float) myCanvas.getWidth() / (float) myCanvas.getHeight();
        pMat.identity().setPerspective((float) Math.toRadians(60.0f), aspect, 0.1f, 1000.0f);

        setupShadowBuffers();
    }

    private void installLight(int renderingProgram, Matrix4f vMat){
        GL4 gl = (GL4) GLContext.getCurrentGL();


        currentLightPos.mulPosition(vMat);
        lightPos[0]=currentLightPos.x();
        lightPos[1]=currentLightPos.y();
        lightPos[2]=currentLightPos.z();

        globalAmbLoc = gl.glGetUniformLocation(renderingProgram, "globalAmbient");
        ambLoc = gl.glGetUniformLocation(renderingProgram, "light.ambient");
        diffLoc = gl.glGetUniformLocation(renderingProgram, "light.diffuse");
        specLoc = gl.glGetUniformLocation(renderingProgram, "light.specular");
        posLoc = gl.glGetUniformLocation(renderingProgram, "light.position");
        mambLoc = gl.glGetUniformLocation(renderingProgram, "material.ambient");
        mdiffLoc = gl.glGetUniformLocation(renderingProgram, "material.diffuse");
        mspecLoc = gl.glGetUniformLocation(renderingProgram, "material.specular");
        mshiLoc = gl.glGetUniformLocation(renderingProgram, "material.shininess");

        gl.glProgramUniform4fv(renderingProgram, globalAmbLoc, 1, globalAmbient, 0);
        gl.glProgramUniform4fv(renderingProgram, ambLoc, 1, lightAmbient, 0);
        gl.glProgramUniform4fv(renderingProgram, diffLoc, 1, lightDiffuse, 0);
        gl.glProgramUniform4fv(renderingProgram, specLoc, 1, lightSpecular, 0);
        gl.glProgramUniform3fv(renderingProgram, posLoc, 1, lightPos, 0);
        gl.glProgramUniform4fv(renderingProgram, mambLoc, 1, matAmb, 0);
        gl.glProgramUniform4fv(renderingProgram, mdiffLoc, 1, matDif, 0);
        gl.glProgramUniform4fv(renderingProgram, mspecLoc, 1, matSpe, 0);
        gl.glProgramUniform1f(renderingProgram, mshiLoc, matShi);

    }

    private void setupShadowBuffers(){
        GL4 gl = (GL4) GLContext.getCurrentGL();
        scSizeX = myCanvas.getWidth();
        scSizeY = myCanvas.getHeight();

        gl.glGenFramebuffers(1, shadowBuffer, 0);

        gl.glGenTextures(1, shadowTex, 0);
        gl.glBindTexture(GL_TEXTURE_2D, shadowTex[0]);
        gl.glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32,
                scSizeX, scSizeY, 0, GL_DEPTH_COMPONENT, GL_FLOAT, null);
        gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
        gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);


        gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }

    /**
     * sets up the vertices and texture coordinates and binds them to vbos
     */
    private void setupVertices(){
        GL4 gl = (GL4) GLContext.getCurrentGL();

        cubeHead = new CubeHead();
        cube = new Cube();
        rectangle = new Rectangle();
        floor = new FloorModel();
        mushroom = new ImportedModel("mushroom.obj");
        shuttle = new ImportedModel("shuttle.obj");
        grid = new ImportedModel("grid.obj");
        tree = new ImportedModel("tree2.obj");



        gl.glGenVertexArrays(vao.length, vao, 0);
        gl.glBindVertexArray(vao[0]);
        gl.glGenBuffers(vbo.length, vbo, 0);

        //binds rectangle model
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
        FloatBuffer rectangleVertBuf = Buffers.newDirectFloatBuffer(rectangle.getVertices());
        gl.glBufferData(GL_ARRAY_BUFFER, rectangleVertBuf.limit()*4, rectangleVertBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
        FloatBuffer rectangleTexBuf = Buffers.newDirectFloatBuffer(rectangle.getTextureCoordinates());
        gl.glBufferData(GL_ARRAY_BUFFER, rectangleTexBuf.limit()*4, rectangleTexBuf, GL_STATIC_DRAW);

        //binds cube model
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
        FloatBuffer cubeVertBuf = Buffers.newDirectFloatBuffer(cubeHead.getVertices());
        gl.glBufferData(GL_ARRAY_BUFFER, cubeVertBuf.limit()*4, cubeVertBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
        FloatBuffer cubeTexBuf = Buffers.newDirectFloatBuffer(cubeHead.getTextureCoordinates());
        gl.glBufferData(GL_ARRAY_BUFFER, cubeTexBuf.limit()*4, cubeTexBuf, GL_STATIC_DRAW);

        //binds mushroom model
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
        FloatBuffer mushVertBuf = Buffers.newDirectFloatBuffer(mushroom.getPValues());
        gl.glBufferData(GL_ARRAY_BUFFER, mushVertBuf.limit()*4, mushVertBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
        FloatBuffer mushTextBuf = Buffers.newDirectFloatBuffer(mushroom.getTValues());
        gl.glBufferData(GL_ARRAY_BUFFER, mushTextBuf.limit()*4, mushTextBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
        FloatBuffer mushNormBuf = Buffers.newDirectFloatBuffer(mushroom.getNValues());
        gl.glBufferData(GL_ARRAY_BUFFER, mushNormBuf.limit()*4, mushNormBuf, GL_STATIC_DRAW);

        //binds grid model
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
        FloatBuffer floorVertBuf = Buffers.newDirectFloatBuffer(grid.getPValues());
        gl.glBufferData(GL_ARRAY_BUFFER, floorVertBuf.limit()*4, floorVertBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
        FloatBuffer floorTextBuf = Buffers.newDirectFloatBuffer(grid.getTValues());
        gl.glBufferData(GL_ARRAY_BUFFER, floorTextBuf.limit()*4, floorTextBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
        FloatBuffer floorNormBuf = Buffers.newDirectFloatBuffer(grid.getNValues());
        gl.glBufferData(GL_ARRAY_BUFFER, floorNormBuf.limit()*4, floorNormBuf, GL_STATIC_DRAW);

        //bind tree model
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
        FloatBuffer treeVertBuf = Buffers.newDirectFloatBuffer(tree.getPValues());
        gl.glBufferData(GL_ARRAY_BUFFER, treeVertBuf.limit()*4, treeVertBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
        FloatBuffer treeTextBuf = Buffers.newDirectFloatBuffer(tree.getTValues());
        gl.glBufferData(GL_ARRAY_BUFFER, treeTextBuf.limit()*4, treeTextBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
        FloatBuffer treeNormBuf = Buffers.newDirectFloatBuffer(tree.getNValues());
        gl.glBufferData(GL_ARRAY_BUFFER, treeNormBuf.limit()*4, treeNormBuf, GL_STATIC_DRAW);

        //binds cube model
        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[20]);
        FloatBuffer lightBoxVertBuf = Buffers.newDirectFloatBuffer(cubeHead.getVertices());
        gl.glBufferData(GL_ARRAY_BUFFER, lightBoxVertBuf.limit()*4, lightBoxVertBuf, GL_STATIC_DRAW);

        gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[21]);
        FloatBuffer lightBoxTextBuf = Buffers.newDirectFloatBuffer(cubeHead.getTextureCoordinates());
        gl.glBufferData(GL_ARRAY_BUFFER, lightBoxTextBuf.limit()*4, lightBoxTextBuf, GL_STATIC_DRAW);

    }

    private void changeToGoldMaterial(){
        GL4 gl = (GL4) GLContext.getCurrentGL();

        matAmb = Utils.goldAmbient();
        matDif = Utils.goldDiffuse();
        matSpe = Utils.goldSpecular();
        matShi = Utils.goldShininess();

        mambLoc = gl.glGetUniformLocation(renderingProgram, "material.ambient");
        mdiffLoc = gl.glGetUniformLocation(renderingProgram, "material.diffuse");
        mspecLoc = gl.glGetUniformLocation(renderingProgram, "material.specular");
        mshiLoc = gl.glGetUniformLocation(renderingProgram, "material.shininess");

        gl.glProgramUniform4fv(renderingProgram, mambLoc, 1, matAmb, 0);
        gl.glProgramUniform4fv(renderingProgram, mdiffLoc, 1, matDif, 0);
        gl.glProgramUniform4fv(renderingProgram, mspecLoc, 1, matSpe, 0);
        gl.glProgramUniform1f(renderingProgram, mshiLoc, matShi);
    }

    private void changeToSilverMaterial(){
        GL4 gl = (GL4) GLContext.getCurrentGL();

        matAmb = Utils.silverAmbient();
        matDif = Utils.silverDiffuse();
        matSpe = Utils.silverSpecular();
        matShi = Utils.silverShininess();

        mambLoc = gl.glGetUniformLocation(renderingProgram, "material.ambient");
        mdiffLoc = gl.glGetUniformLocation(renderingProgram, "material.diffuse");
        mspecLoc = gl.glGetUniformLocation(renderingProgram, "material.specular");
        mshiLoc = gl.glGetUniformLocation(renderingProgram, "material.shininess");

        gl.glProgramUniform4fv(renderingProgram, mambLoc, 1, matAmb, 0);
        gl.glProgramUniform4fv(renderingProgram, mdiffLoc, 1, matDif, 0);
        gl.glProgramUniform4fv(renderingProgram, mspecLoc, 1, matSpe, 0);
        gl.glProgramUniform1f(renderingProgram, mshiLoc, matShi);
    }
    //rubber black
    private void changeToMatMaterial(){
        GL4 gl = (GL4) GLContext.getCurrentGL();

        float[] amb = {.2f,.2f,.2f ,1.0f};
        float[] dif = {.01f, .01f, .01f, 1.0f};
        float[] spec = {.4f, .4f, .4f, 1.0f};


        matAmb = amb;
        matDif = dif;
        matSpe = spec;
        matShi = .078125f;

        mambLoc = gl.glGetUniformLocation(renderingProgram, "material.ambient");
        mdiffLoc = gl.glGetUniformLocation(renderingProgram, "material.diffuse");
        mspecLoc = gl.glGetUniformLocation(renderingProgram, "material.specular");
        mshiLoc = gl.glGetUniformLocation(renderingProgram, "material.shininess");

        gl.glProgramUniform4fv(renderingProgram, mambLoc, 1, matAmb, 0);
        gl.glProgramUniform4fv(renderingProgram, mdiffLoc, 1, matDif, 0);
        gl.glProgramUniform4fv(renderingProgram, mspecLoc, 1, matSpe, 0);
        gl.glProgramUniform1f(renderingProgram, mshiLoc, matShi);
    }

    /**
     * calls constructor
     * @param args arguements
     */
    public static void main(String[] args){
       new Starter();
    }

    @Override
    public void keyTyped(KeyEvent keyEvent) {}

    /**
     *  key pushed
     * @param keyEvent key pushed
     */
    @Override
    public void keyPressed(KeyEvent keyEvent) {
        switch(keyEvent.getKeyCode()){
            //key push a, move camera left
            case KeyEvent.VK_A:
                camera.moveLeft();
                System.out.println("press a");
                break;
            //key push s, move camera back
            case KeyEvent.VK_S:
                camera.moveBack();
                System.out.println("press s");
                break;
            //key push d, move camera right
            case KeyEvent.VK_D:
                camera.moveRight();
                System.out.println("press d");
                break;
            //key push w, move camera forward
            case KeyEvent.VK_W:
                camera.moveForward();
                System.out.println("press w");
                break;
            // key push q, moves up
            case KeyEvent.VK_Q:
                camera.moveUp();
                System.out.println("press w");
                break;
            // key push e moves down
            case KeyEvent.VK_E:
                camera.moveDown();
                System.out.println("press w");
                break;
            // key push left look left
            case KeyEvent.VK_LEFT:
                camera.lookLeft();
                break;
            // key push down look down
            case KeyEvent.VK_DOWN:
                camera.lookDown();
                break;
            // key push right look right
            case KeyEvent.VK_RIGHT:
                camera.lookRight();
                break;
            // key push up, look up
            case KeyEvent.VK_UP:
                camera.lookUp();
                break;
            case KeyEvent.VK_SPACE:
                axisFlag = (axisFlag) ? false : true;
                break;
            case KeyEvent.VK_G:
                globalAmbSwitch = (globalAmbSwitch == 0) ? 1 : 0;
                System.out.println(globalAmbSwitch);
                break;
        }
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        //scroll up
        if(e.getWheelRotation() == 1){
            initialLightLoc.add(new Vector3f(0.0f, 0.0f, 0.5f));
            System.out.println("working");
            System.out.println(initialLightLoc.toString());
        }else if (e.getWheelRotation() == -1){
            initialLightLoc.sub(new Vector3f(0.0f, 0.0f, 0.5f));
        }
    }
    @Override
    public void mousePressed(MouseEvent e) {
        originalDraggedPositionX = e.getX();
        originalDraggedPositionY = e.getY();
    }
    @Override
    public void mouseDragged(MouseEvent e) {
        int draggedAmountX;
        int draggedAmountY;

        draggedAmountX = -(originalDraggedPositionX - e.getX());
        draggedAmountY = originalDraggedPositionY - e.getY();

        originalDraggedPositionX = e.getX();
        originalDraggedPositionY = e.getY();
        initialLightLoc.add(new Vector3f((draggedAmountX* 0.1f), (draggedAmountY * 0.1f), 0.0f));
        //initialLightLoc.add(new Vector3f((draggedAmountX * 0.05f), (draggedAmountY * 0.05f), 0.0f));
    }

    @Override
    public void keyReleased(KeyEvent keyEvent) {}
    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
