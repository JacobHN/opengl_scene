package a3;


import org.joml.Vector3f;

public class FloorModel {
    private float[] positionCoordinates =
            {
                    -1.0f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, -1.0f,//top up
                    1.0f, 0.0f, 1.0f, -1.0f, 0.0f, -1.0f, -1.0f, 0.0f, 1.0f,//top down
            };

    private float[] textureCoordinates =
            {
                    1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
                    0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
            };

    private float[] nCoordinates;

    public FloorModel(){
        createNVector();
    }

    private void createNVector(){
        int vertexAmount = positionCoordinates.length;
        Vector3f index1;
        Vector3f index2;
        Vector3f index3;

        Vector3f edge1;
        Vector3f edge2;

        Vector3f normal;

        int vertex;

        for(int i = 0; i <= vertexAmount - 1; i+=9){
            index1 = new Vector3f(positionCoordinates[i], positionCoordinates[i + 1], positionCoordinates[i + 2]);
            index2 = new Vector3f(positionCoordinates[i+3], positionCoordinates[i + 4], positionCoordinates[i + 5]);
            index3 = new Vector3f(positionCoordinates[i+ 6], positionCoordinates[i + 7], positionCoordinates[i + 8]);

            edge1 = index1.min(index2);
            edge2 = index2.min(index3);

            normal = edge1.cross(edge2);


        }

    }

    public float[] getVertices(){
        return positionCoordinates;
    }
    public float[] getTextureCoordinates(){ return textureCoordinates;}
    public float[] getNCoordinates(){return nCoordinates;};
}
